$(document).ready(function(){

	$(".leftbar-menu").on("click", function(){
		$(".left-bar").toggle();

	});

	$(".rightbar-btn").on("click", function(){
		$(".right-bar").toggle();
	});

	$(".profile-img").on("click", function(){
		$(".profile-details").toggle();
	});


	$(".profile-img").on('submit', function(e) {

 		e.preventDefault();
  		console.log('submitted');

	});
    
    $('.submit-btn').on('change', function() { 

    let userfile = $(this).val();
    if(userfile) { 
      $('.profile-img').submit();
    }
	}); 
	$('.profile-img').on('click' , function(){ 
  		$('.submit-btn').click();
});

});